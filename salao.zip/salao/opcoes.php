<?php
// Listas de opções usadas nos formulários da ficha capilar (fichas.php e editar_ficha.php)
$tipos_cabelo = ['Liso', 'Ondulado', 'Cacheado', 'Crespo'];
$comprimentos = ['Curto', 'Médio', 'Longo'];
$quimicas     = ['Nenhuma', 'Coloração', 'Descoloração', 'Alisamento', 'Progressiva', 'Permanente'];
