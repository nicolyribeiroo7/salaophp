<?php
// Histórico de atendimentos do salão, com os dados da ficha capilar e do cliente

// Inicia a sessão para acessar dados do usuário autenticado
session_start();

// Verifica se o usuário está logado; se não, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para conexão com o banco de dados
include 'config.php';

// Monta a consulta SQL para buscar o histórico de atendimentos
// Traz TODOS os dados da ficha (tipo de cabelo, comprimento, cor, química e alergias)
// e do cliente (nome, CPF, telefone e e-mail)
// A consulta une as tabelas atendimentos, fichas e clientes seguindo os relacionamentos:
// atendimentos.ficha_id -> fichas.id e fichas.cliente_id -> clientes.id
// Os registros são ordenados pela data do atendimento (do mais antigo para o mais novo)
// Por dia: ORDER BY a.data
// Por mês: ORDER BY MONTH(a.data), a.data
// Por ano: ORDER BY YEAR(a.data), a.data
$sql = "SELECT a.id, a.data, a.descricao, a.profissional, a.valor,
               f.tipo_cabelo, f.comprimento, f.cor_atual, f.quimica, f.alergias,
               c.nome AS cliente_nome, CAST(AES_DECRYPT(c.cpf, '$chave') AS CHAR) AS cliente_cpf,
               c.telefone, c.email
        FROM atendimentos a
        JOIN fichas f ON a.ficha_id = f.id
        JOIN clientes c ON f.cliente_id = c.id
        ORDER BY a.data";

// Executa a consulta no banco de dados
$result = $conn->query($sql);
?>
<meta charset="UTF-8">
<title>Histórico de Atendimentos</title>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<!-- Título da página -->
<h2>Histórico de Atendimentos</h2>

<!-- Tabela para exibir o histórico com todos os dados do atendimento, da ficha e do cliente -->
<table border="1" cellpadding="5">
    <tr>
        <th>ID</th>
        <th>Data</th>
        <th>Serviço</th>
        <th>Profissional</th>
        <th>Valor (R$)</th>
        <th>Tipo de cabelo</th>
        <th>Comprimento</th>
        <th>Cor atual</th>
        <th>Química</th>
        <th>Alergias</th>
        <th>Cliente</th>
        <th>CPF</th>
        <th>Telefone</th>
        <th>E-mail</th>
        <th>Ações</th>
    </tr>

    <!-- Iteração sobre cada registro retornado do banco para popular as linhas da tabela -->
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <!-- Exibe o ID do atendimento -->
        <td><?= intval($row['id']) ?></td>
        <!-- Exibe a data do atendimento no formato dia/mês/ano -->
        <td><?= date('d/m/Y', strtotime($row['data'])) ?></td>
        <!-- Exibe o serviço realizado e a profissional -->
        <td><?= htmlspecialchars($row['descricao']) ?></td>
        <td><?= htmlspecialchars($row['profissional'] ?? '') ?></td>
        <!-- Exibe o valor do atendimento com duas casas decimais -->
        <td><?= number_format($row['valor'], 2, ',', '.') ?></td>
        <!-- Dados da ficha capilar -->
        <td><?= htmlspecialchars($row['tipo_cabelo']) ?></td>
        <td><?= htmlspecialchars($row['comprimento']) ?></td>
        <td><?= htmlspecialchars($row['cor_atual'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['quimica'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['alergias'] ?? '') ?></td>
        <!-- Dados do cliente (o CPF aparece descriptografado) -->
        <td><?= htmlspecialchars($row['cliente_nome']) ?></td>
        <td><?= htmlspecialchars($row['cliente_cpf'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['telefone'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
        <td>
            <!-- Link para editar o atendimento, passando o ID via GET -->
            <a href="editar_atendimento.php?id=<?= $row['id'] ?>">Editar</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<!-- Link para voltar à página principal do sistema -->
<a href="principal.php">Voltar</a>
