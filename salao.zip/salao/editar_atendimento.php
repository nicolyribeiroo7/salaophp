<?php

// Inicia a sessão para acessar os dados do usuário logado
session_start();

// Verifica se o usuário está autenticado; caso contrário, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para estabelecer a conexão com a base de dados
include 'config.php';

// Recebe o ID do atendimento a ser editado via parâmetro GET na URL; se não informado, assume 0
$id = $_GET['id'] ?? 0;

// Prepara e executa uma consulta para buscar o atendimento e o cliente da ficha em que ele foi feito
$sql = "SELECT a.*, c.nome AS cliente_nome, f.tipo_cabelo
        FROM atendimentos a
        JOIN fichas f ON a.ficha_id = f.id
        JOIN clientes c ON f.cliente_id = c.id
        WHERE a.id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$atendimento = $res->fetch_assoc();

// Se não encontrou o atendimento, exibe mensagem e termina a execução
if (!$atendimento) {
    echo "Atendimento não encontrado.";
    exit();
}

// Processa o formulário quando enviado via POST para atualizar o atendimento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Coleta os dados atualizados do formulário
    $data = $_POST['data'];
    $descricao = $_POST['descricao'];
    $profissional = $_POST['profissional'];
    $valor = $_POST['valor'] !== '' ? $_POST['valor'] : 0;

    // Validação simples: data e descrição são obrigatórias
    if (!$data || !$descricao) {
        echo "Data e descrição são obrigatórias.";
    } else {
        // Atualiza a data, o serviço, a profissional e o valor do atendimento no banco de dados
        $sql = "UPDATE atendimentos SET data=?, descricao=?, profissional=?, valor=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssdi", $data, $descricao, $profissional, $valor, $id);
        $stmt->execute();

        // Redireciona o usuário de volta para o histórico após atualizar
        header("Location: historico.php");
        exit();
    }
}
?>
<meta charset="UTF-8">
<title>Editar Atendimento</title>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<h2>Editar Atendimento</h2>

<!-- Mostra de qual cliente é o atendimento -->
<p>Cliente: <?= htmlspecialchars($atendimento['cliente_nome'] . ' - cabelo ' . strtolower($atendimento['tipo_cabelo'])) ?></p>

<!-- Formulário para edição do atendimento com dados já preenchidos -->
<form method="post">
    <label for="data">Data:</label>
    <input type="date" id="data" name="data" value="<?= htmlspecialchars($atendimento['data']) ?>" required>
    <br><br>

    <label for="descricao">Serviço:</label>
    <input type="text" id="descricao" name="descricao" value="<?= htmlspecialchars($atendimento['descricao']) ?>" required>
    <br><br>

    <label for="profissional">Profissional:</label>
    <input type="text" id="profissional" name="profissional" value="<?= htmlspecialchars($atendimento['profissional'] ?? '') ?>">
    <br><br>

    <label for="valor">Valor (R$):</label>
    <input type="number" step="0.01" min="0" id="valor" name="valor" value="<?= htmlspecialchars($atendimento['valor']) ?>">
    <br><br>

    <button>Salvar</button>
</form>

<!-- Link para voltar ao histórico -->
<a href="historico.php">Voltar</a>
