<?php

// Inicia a sessão para acessar dados do usuário logado e verificar autenticação
session_start();

// Se o usuário não estiver autenticado, redireciona para a página de login e encerra o script
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração que contém a conexão com o banco de dados
include 'config.php';

// Inicializa variável para armazenar mensagens de alerta que poderão ser exibidas para o usuário
$alerta = '';

// Verifica se o formulário foi submetido via método POST para registrar o atendimento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recebe e sanitiza os dados enviados pelo formulário
    $ficha_id = intval($_POST['ficha_id']); // Ficha em que o atendimento foi feito
    $data = $_POST['data'];
    $descricao = $_POST['descricao'];
    $profissional = $_POST['profissional'];
    $valor = $_POST['valor'] !== '' ? $_POST['valor'] : 0;

    // Verifica se os campos obrigatórios foram preenchidos
    if (!$ficha_id || !$data || !$descricao) {
        $alerta = "Ficha, data e descrição são obrigatórias.";
    } else {
        // Prepara a inserção do atendimento no banco de dados
        // O campo ficha_id liga o atendimento à ficha (uma ficha tem muitos atendimentos)
        $stmt = $conn->prepare("INSERT INTO atendimentos (ficha_id, data, descricao, profissional, valor) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isssd", $ficha_id, $data, $descricao, $profissional, $valor);
        $stmt->execute();

        // Redireciona para o histórico para mostrar o atendimento registrado
        header('Location: historico.php');
        exit;
    }
}
// Consulta SQL para buscar todas as fichas (com o nome do cliente) para popular o select no formulário
$sql = "SELECT f.id, f.tipo_cabelo, f.cor_atual, c.nome AS cliente_nome
        FROM fichas f
        JOIN clientes c ON f.cliente_id = c.id
        ORDER BY c.nome";
$res = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Registrar Atendimento</title>
    <!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<h2>Registrar Atendimento</h2>

<!-- Exibe mensagem de alerta em destaque, caso tenha sido definida -->
<?php if ($alerta): ?>
    <div class="erro">
        <?= htmlspecialchars($alerta) ?>
    </div>
<?php endif; ?>

<!-- Formulário de registro do atendimento -->
<form action="" method="post">
    <label for="ficha_id">Cliente / Ficha:</label>
    <select id="ficha_id" name="ficha_id" required>
        <!-- Preenche o select com as fichas obtidas do banco (cliente, tipo de cabelo e cor) -->
        <?php while ($row = $res->fetch_assoc()): ?>
            <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['cliente_nome'] . ' - cabelo ' . strtolower($row['tipo_cabelo']) . ($row['cor_atual'] ? ' (' . $row['cor_atual'] . ')' : '')) ?></option>
        <?php endwhile; ?>
    </select>
    <br><br>

    <label for="data">Data:</label>
    <input type="date" id="data" name="data" required>
    <br><br>

    <label for="descricao">Serviço:</label>
    <input type="text" id="descricao" name="descricao" placeholder="Ex.: corte, escova, coloração..." required>
    <br><br>

    <label for="profissional">Profissional:</label>
    <input type="text" id="profissional" name="profissional">
    <br><br>

    <label for="valor">Valor (R$):</label>
    <input type="number" step="0.01" min="0" id="valor" name="valor">
    <br><br>

    <button type="submit">Registrar</button>
</form>

<br>
<a href="principal.php">Voltar</a>

</body>
</html>
