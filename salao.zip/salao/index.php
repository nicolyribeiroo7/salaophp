<?php
// Página inicial: quem abrir http://localhost/salao/ é mandado para o login
header('Location: login.php');
exit();
