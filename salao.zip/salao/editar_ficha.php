<?php

// Inicia a sessão para acessar os dados do usuário logado
session_start();

// Verifica se o usuário está autenticado; caso contrário, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para estabelecer a conexão com a base de dados
include 'config.php';

// Inclui as listas de opções (tipo de cabelo, comprimento e química)
include 'opcoes.php';

// Recebe o ID da ficha a ser editada via parâmetro GET na URL; se não informado, assume 0
$id = $_GET['id'] ?? 0;

// Prepara e executa uma consulta para buscar os dados da ficha com o ID informado
$sql = "SELECT * FROM fichas WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$ficha = $res->fetch_assoc();

// Se não encontrou a ficha, exibe mensagem e termina a execução
if (!$ficha) {
    echo "Ficha não encontrada.";
    exit();
}

// Processa o formulário quando enviado via POST para atualizar a ficha
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Coleta os dados atualizados do formulário
    $cliente_id = $_POST['cliente_id'];
    $tipo_cabelo = $_POST['tipo_cabelo'];
    $comprimento = $_POST['comprimento'];
    $cor_atual = $_POST['cor_atual'];
    $quimica = $_POST['quimica'];
    $alergias = $_POST['alergias'];

    // Validação simples: cliente, tipo de cabelo e comprimento são obrigatórios
    if (!$cliente_id || !$tipo_cabelo || !$comprimento) {
        echo "Cliente, tipo de cabelo e comprimento são obrigatórios.";
    } else {
        // Atualiza os dados da ficha no banco de dados
        $sql = "UPDATE fichas SET cliente_id=?, tipo_cabelo=?, comprimento=?, cor_atual=?, quimica=?, alergias=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isssssi", $cliente_id, $tipo_cabelo, $comprimento, $cor_atual, $quimica, $alergias, $id);
        $stmt->execute();

        // Redireciona o usuário de volta para a lista de fichas após atualizar
        header("Location: fichas.php");
        exit();
    }
}

// Busca todos os clientes para preencher o select (permite trocar o cliente da ficha)
$clientes = $conn->query("SELECT id, nome FROM clientes ORDER BY nome");
?>
<meta charset="UTF-8">
<title>Editar Ficha</title>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<h2>Editar Ficha Capilar</h2>

<!-- Formulário para edição da ficha com dados já preenchidos -->
<form method="post">
    <select name="cliente_id" required>
        <!-- Deixa selecionado o cliente atual da ficha -->
        <?php while ($c = $clientes->fetch_assoc()): ?>
            <option value="<?= $c['id'] ?>" <?= $c['id'] == $ficha['cliente_id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['nome']) ?></option>
        <?php endwhile; ?>
    </select>

    <select name="tipo_cabelo" required>
        <?php foreach ($tipos_cabelo as $t): ?>
            <option value="<?= $t ?>" <?= $t == $ficha['tipo_cabelo'] ? 'selected' : '' ?>><?= $t ?></option>
        <?php endforeach; ?>
    </select>

    <select name="comprimento" required>
        <?php foreach ($comprimentos as $c): ?>
            <option value="<?= $c ?>" <?= $c == $ficha['comprimento'] ? 'selected' : '' ?>><?= $c ?></option>
        <?php endforeach; ?>
    </select>

    <input name="cor_atual" placeholder="Cor atual" value="<?= htmlspecialchars($ficha['cor_atual'] ?? '') ?>">

    <select name="quimica">
        <?php foreach ($quimicas as $q): ?>
            <option value="<?= $q ?>" <?= $q == $ficha['quimica'] ? 'selected' : '' ?>><?= $q ?></option>
        <?php endforeach; ?>
    </select>

    <input name="alergias" placeholder="Alergias / observações" value="<?= htmlspecialchars($ficha['alergias'] ?? '') ?>">
    <button>Salvar</button>
</form>

<!-- Link para voltar à página de listagem de fichas -->
<a href="fichas.php">Voltar</a>
