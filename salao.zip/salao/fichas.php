<?php

// Inicia a sessão para verificar se o usuário está autenticado
session_start();

// Se não houver usuário logado, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para conexão com o banco de dados
include 'config.php';

// Inclui as listas de opções (tipo de cabelo, comprimento e química)
include 'opcoes.php';

// Verifica se o formulário de cadastro foi enviado via POST e o botão 'add' foi clicado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    // Prepara uma consulta segura para inserir uma nova ficha, evitando SQL Injection
    // O campo cliente_id liga a ficha ao seu cliente (um cliente tem muitas fichas)
    $stmt = $conn->prepare(
        "INSERT INTO fichas (cliente_id, tipo_cabelo, comprimento, cor_atual, quimica, alergias)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    // Liga os parâmetros enviados no formulário aos marcadores da consulta preparada
    $stmt->bind_param(
        "isssss",
        $_POST['cliente_id'],
        $_POST['tipo_cabelo'],
        $_POST['comprimento'],
        $_POST['cor_atual'],
        $_POST['quimica'],
        $_POST['alergias']
    );
    // Executa a inserção no banco
    $stmt->execute();
    // Após adicionar a ficha, redireciona para a mesma página para atualizar a lista
    header("Location: fichas.php");
    exit();
}

// Recebe o termo de busca enviado via GET, ou vazio se não houver
$busca = $_GET['busca'] ?? '';

// Protege o termo de busca contra SQL Injection antes de colocar na consulta
$termo = $conn->real_escape_string($busca);

// Monta a cláusula WHERE da consulta para filtrar fichas pelo nome do cliente, tipo de cabelo ou cor
$where = $busca ? "WHERE c.nome LIKE '%$termo%' OR f.tipo_cabelo LIKE '%$termo%' OR f.cor_atual LIKE '%$termo%'" : '';

// Consulta SQL que une fichas e clientes (JOIN) para mostrar o nome do cliente de cada ficha
$query = "SELECT f.*, c.nome AS cliente_nome
          FROM fichas f
          JOIN clientes c ON f.cliente_id = c.id
          $where
          ORDER BY c.nome";

// Executa a consulta e armazena o resultado
$fichas = $conn->query($query);

// Busca todos os clientes para preencher o select do formulário de cadastro
$clientes = $conn->query("SELECT id, nome FROM clientes ORDER BY nome");
?>
<meta charset="UTF-8">
<title>Ficha Capilar</title>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<h2>Ficha Capilar</h2>

<!-- Formulário para pesquisa de fichas -->
<form method="get">
    <input name="busca" placeholder="Buscar por cliente, tipo de cabelo ou cor..." value="<?= htmlspecialchars($busca) ?>">
    <button type="submit">Buscar</button>
    <a href="principal.php">Voltar</a>
</form>

<!-- Tabela exibindo as fichas buscadas/listadas -->
<table border="1" cellpadding="5">
    <tr><th>Cliente</th><th>Tipo de cabelo</th><th>Comprimento</th><th>Cor atual</th><th>Química</th><th>Alergias</th><th>Ações</th></tr>
    <?php while($row = $fichas->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['cliente_nome']) ?></td>
        <td><?= htmlspecialchars($row['tipo_cabelo']) ?></td>
        <td><?= htmlspecialchars($row['comprimento']) ?></td>
        <td><?= htmlspecialchars($row['cor_atual'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['quimica'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['alergias'] ?? '') ?></td>
        <td>
            <!-- Link para editar a ficha, passando o ID via GET -->
            <a href="editar_ficha.php?id=<?= $row['id'] ?>">Editar</a>
            <!-- Link para deletar a ficha, com confirmação (os atendimentos dela também são apagados) -->
            <a href="deletar_ficha.php?id=<?= $row['id'] ?>" onclick="return confirm('Excluir a ficha apaga também os atendimentos dela. Confirma?')">Excluir</a>
        </td>
      </tr>
    <?php endwhile; ?>
</table>

<!-- Formulário para cadastro de nova ficha -->
<h3>Nova ficha</h3>
<form method="post">
    <!-- Select com os clientes cadastrados: o valor enviado é o id do cliente -->
    <select name="cliente_id" required>
        <option value="">Selecione o cliente</option>
        <?php while ($c = $clientes->fetch_assoc()): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nome']) ?></option>
        <?php endwhile; ?>
    </select>

    <select name="tipo_cabelo" required>
        <option value="">Tipo de cabelo</option>
        <?php foreach ($tipos_cabelo as $t): ?>
            <option value="<?= $t ?>"><?= $t ?></option>
        <?php endforeach; ?>
    </select>

    <select name="comprimento" required>
        <option value="">Comprimento</option>
        <?php foreach ($comprimentos as $c): ?>
            <option value="<?= $c ?>"><?= $c ?></option>
        <?php endforeach; ?>
    </select>

    <input name="cor_atual" placeholder="Cor atual">

    <select name="quimica">
        <?php foreach ($quimicas as $q): ?>
            <option value="<?= $q ?>"><?= $q ?></option>
        <?php endforeach; ?>
    </select>

    <input name="alergias" placeholder="Alergias / observações">
    <button name="add">Cadastrar</button>
</form>
