<?php
// Configuração da conexão com o banco de dados MySQL usando MySQLi.
// Aceita valores vindos do ambiente ou usa valores padrões para XAMPP/WAMP.

$servername = getenv('DB_HOST') ?: 'localhost';
$username   = getenv('DB_USER') ?: 'root';
$password   = getenv('DB_PASS') ?: 'Senai@118'; // senha vazia é o padrão em alguns ambientes locais
$dbname     = getenv('DB_NAME') ?: 'salao_db';

// Chave usada para criptografar e descriptografar o CPF com AES_ENCRYPT / AES_DECRYPT.
// Deve ser igual à do script salao_db.sql.
$chave = getenv('APP_KEY') ?: 'salao2026';

$conn = null;

// Desativa falhas fatais do mysqli para permitir uma mensagem amigável no login.
mysqli_report(MYSQLI_REPORT_OFF);

// Tenta criar a conexão com o banco.
$conn = @new mysqli($servername, $username, $password, $dbname);

if ($conn && $conn->connect_error) {
    $conn = null;
}

// Se a conexão existir, ajusta o charset.
if ($conn) {
    $conn->set_charset('utf8mb4');
}
?>
