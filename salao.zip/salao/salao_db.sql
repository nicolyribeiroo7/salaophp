-- Banco de dados do sistema do Salão de Beleza
-- Execute este script inteiro no MySQL (phpMyAdmin > SQL, ou: mysql -u root -p < salao_db.sql)
-- Ele cria um banco NOVO (salao_db) e não mexe no banco antigo da oficina.

DROP DATABASE IF EXISTS salao_db;
CREATE DATABASE salao_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE salao_db;

-- Usuários que podem entrar no sistema (senha guardada como hash, nunca em texto puro)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL
);

-- Clientes do salão (CPF criptografado com AES_ENCRYPT - LGPD)
-- A chave usada aqui TEM que ser a mesma de $chave no config.php ('salao2026')
CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARBINARY(255) NOT NULL,
    telefone VARCHAR(20),
    email VARCHAR(100)
);

-- Ficha capilar: cada cliente pode ter várias fichas (1 cliente -> N fichas)
CREATE TABLE fichas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    tipo_cabelo VARCHAR(30) NOT NULL,   -- Liso, Ondulado, Cacheado, Crespo
    comprimento VARCHAR(30) NOT NULL,   -- Curto, Médio, Longo
    cor_atual VARCHAR(50),
    quimica VARCHAR(50),                -- química já feita no cabelo
    alergias VARCHAR(150),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);

-- Atendimentos: cada ficha pode ter vários atendimentos (1 ficha -> N atendimentos)
CREATE TABLE atendimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ficha_id INT NOT NULL,
    data DATE NOT NULL,
    descricao VARCHAR(255) NOT NULL,    -- serviço realizado (corte, escova, coloração...)
    profissional VARCHAR(100),
    valor DECIMAL(10,2) NOT NULL DEFAULT 0,
    FOREIGN KEY (ficha_id) REFERENCES fichas(id) ON DELETE CASCADE
);

-- Usuário inicial: login "admin" / senha "admin123" (troque depois!)
INSERT INTO usuarios (nome, senha) VALUES ('admin', '$2y$12$d6MzlyV6Etf/a1tvmqfB3uyxO/PDiRYos128LnGdMzTnu2rPXwur6');

-- Dados de exemplo
INSERT INTO clientes (nome, cpf, telefone, email) VALUES
('Mariana Souza',  AES_ENCRYPT('12345678901', 'salao2026'), '(11) 98888-1111', 'mariana@email.com'),
('Camila Ferreira', AES_ENCRYPT('98765432100', 'salao2026'), '(11) 97777-2222', 'camila@email.com');

INSERT INTO fichas (cliente_id, tipo_cabelo, comprimento, cor_atual, quimica, alergias) VALUES
(1, 'Cacheado', 'Longo', 'Castanho escuro', 'Nenhuma', ''),
(2, 'Liso', 'Médio', 'Loiro', 'Descoloração', 'Alergia a amônia');

INSERT INTO atendimentos (ficha_id, data, descricao, profissional, valor) VALUES
(1, '2026-10-05', 'Corte e hidratação', 'Juliana', 120.00),
(2, '2026-10-10', 'Retoque de raiz e escova', 'Patrícia', 280.00);
